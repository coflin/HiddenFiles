#!/bin/bash
./HiddenPython.sh | column
